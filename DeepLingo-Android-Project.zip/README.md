# DeepLingo Android app

A starter Android app for context-aware English ↔ Bengali translation using Gemini 2.5 Flash.

## Build APK
1. Install Android Studio on a computer.
2. Open this `DeepLingo` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Find the APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Set up AI
1. Open Google AI Studio: https://aistudio.google.com/app/apikey
2. Create an API key.
3. Install and open DeepLingo, paste the key into the Gemini API Key field, and tap Save API key.

## Important security note
This starter app stores the API key locally on the device and sends it directly to Google's Gemini API. Do not distribute an APK containing your personal API key. For a public app, use a secure backend that keeps the API key on the server, plus authentication and rate limits.

## Requirements
- Android Studio with Android SDK 35
- JDK 17
- Internet connection

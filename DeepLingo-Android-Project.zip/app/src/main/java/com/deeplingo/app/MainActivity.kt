package com.deeplingo.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.*
import java.io.IOException

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 24)
    private val panel = Color.rgb(29, 29, 42)
    private val purple = Color.rgb(124, 92, 252)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(170, 170, 190)
    private val client = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var apiKey: EditText
    private lateinit var mode: Spinner
    private lateinit var translateButton: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val prefs = getSharedPreferences("deeplingo", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }

        val brand = TextView(this).apply {
            text = "DeepLingo"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        content.addView(brand)
        content.addView(label("Beyond literal translation."))
        content.addView(space(18))

        content.addView(label("TRANSLATION MODE"))
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Deep Translation", "Philosophy & Logic", "Word-by-word explanation", "Natural conversational Bengali"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        content.addView(mode, matchWrap())
        content.addView(space(14))

        content.addView(label("TEXT TO TRANSLATE"))
        input = EditText(this).apply {
            hint = "Write or paste your text here..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            gravity = Gravity.TOP
            minLines = 5
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, dp(150)))
        content.addView(space(14))

        translateButton = Button(this).apply {
            text = "Translate deeply"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            textSize = 16f
        }
        content.addView(translateButton, matchWrap())
        status = label("Ready")
        content.addView(status)
        content.addView(space(14))

        content.addView(label("DEEP TRANSLATION"))
        output = TextView(this).apply {
            text = "Your thoughtful translation will appear here."
            textSize = 16f
            setTextColor(white)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            minHeight = dp(150)
        }
        content.addView(output, matchWrap())
        val copy = Button(this).apply {
            text = "Copy translation"
            isAllCaps = false
            setOnClickListener {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("DeepLingo translation", output.text))
                Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(copy, matchWrap())
        content.addView(space(22))

        content.addView(label("GEMINI API KEY"))
        apiKey = EditText(this).apply {
            hint = "Paste your Gemini API key"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            inputType = 129
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(panel)
            setText(prefs.getString("api_key", "") ?: "")
        }
        content.addView(apiKey, matchWrap())
        content.addView(label("Get a key from Google AI Studio. It is stored on this device."))
        val save = Button(this).apply {
            text = "Save API key"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().putString("api_key", apiKey.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "API key saved on this device", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(save, matchWrap())
        content.addView(space(12))
        content.addView(label("Tip: For best results, include the surrounding paragraph when translating a sentence."))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)

        translateButton.setOnClickListener { doTranslate() }
    }

    private fun doTranslate() {
        val text = input.text.toString().trim()
        val key = apiKey.text.toString().trim()
        if (text.isEmpty()) { input.error = "Enter text first"; return }
        if (key.isEmpty()) { apiKey.error = "Add your Gemini API key"; return }

        val selectedMode = mode.selectedItem.toString()
        val instruction = when (selectedMode) {
            "Philosophy & Logic" -> "Translate with strict philosophical and logical accuracy. Preserve technical distinctions, argument structure, and terms. Add concise explanations of difficult concepts."
            "Word-by-word explanation" -> "Give a natural Bengali translation, then explain important words and phrases individually, including context-specific meanings."
            "Natural conversational Bengali" -> "Translate into natural, fluent Bengali as a native educated Bengali speaker would write. Avoid awkward literal phrasing."
            else -> "Translate deeply, not mechanically. Understand context, intended meaning, nuance, tone, and idioms. Give an accurate natural Bengali translation, then briefly explain any ambiguity or important nuance."
        }
        val prompt = """
You are DeepLingo, an expert English-Bengali translator and language analyst.
$instruction
If the source is Bengali, translate into natural English. If it is English, translate into natural Bengali.
Do not invent context. If a phrase is genuinely ambiguous, mention the plausible meanings.
Structure the answer clearly:
TRANSLATION
[the best translation]
MEANING & NUANCE
[brief explanation in simple language]
IMPORTANT WORDS
[only when useful]
SOURCE TEXT:
$text
""".trimIndent()

        translateButton.isEnabled = false
        status.text = "Translating..."
        output.text = "Please wait..."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { callGemini(key, prompt) }
                output.text = result
                status.text = "Translation complete"
            } catch (e: Exception) {
                output.text = "Could not translate.\n\n${e.message ?: "Check your internet and API key."}"
                status.text = "Something went wrong"
            } finally {
                translateButton.isEnabled = true
            }
        }
    }

    @Throws(IOException::class)
    private fun callGemini(key: String, prompt: String): String {
        val bodyJson = JSONObject().put("contents",
            JSONArray().put(JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", prompt)))))
        val body = bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val msg = try { JSONObject(responseText).getJSONObject("error").optString("message") }
                          catch (_: Exception) { "HTTP ${response.code}" }
                throw IOException(msg)
            }
            val json = JSONObject(responseText)
            return json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
        }
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 13f
        setTextColor(muted)
        setPadding(0, dp(5), 0, dp(7))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
